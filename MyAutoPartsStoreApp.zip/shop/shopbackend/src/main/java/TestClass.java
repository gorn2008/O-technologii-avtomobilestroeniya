import java.util.List;

import com.senla.dao.AutopartDAO;
import com.senla.dao.BrandDAO;
import com.senla.dao.CarDAO;
import com.senla.dao.OrderDAO;
import com.senla.dao.UserAddressDAO;
import com.senla.dao.UserCredsDAO;
import com.senla.dao.UserDAO;
import com.senla.dao.search.AutopartSearchParams;
import com.senla.dao.search.CarSearchParams;
import com.senla.dao.search.UserSearchParams;
import com.senla.model.Autopart;
import com.senla.model.Brand;
import com.senla.model.Car;
import com.senla.model.Order;
import com.senla.model.User;
import com.senla.model.UserAddress;
import com.senla.model.UserCreds;
import com.senla.service.AutopartService;
import com.senla.service.BrandService;
import com.senla.service.CarService;
import com.senla.service.OrderService;
import com.senla.service.UserAddressService;
import com.senla.service.UserCredsService;
import com.senla.service.UserService;

public class TestClass {

	public static void main(String[] args) {
		BrandDAO brandDao = new BrandDAO();
		AutopartDAO autopartDao = new AutopartDAO();
		UserDAO userDao = new UserDAO();
		CarDAO carDao = new CarDAO();
		OrderDAO orderDao = new OrderDAO();
		UserAddressDAO uaDao = new UserAddressDAO();
		UserCredsDAO ucDao = new UserCredsDAO();
		
		BrandService brandsService = new BrandService();
		AutopartService autopartService = new AutopartService();
		UserService userService = new UserService();
		CarService carService = new CarService();
		OrderService orderService = new OrderService();
		UserAddressService uaService = new UserAddressService();
		UserCredsService ucService = new UserCredsService();
		
		brandsService.setBrandDAO(brandDao);
		autopartService.setDao(autopartDao);
		userService.setDao(userDao);
		carService.setDao(carDao);
		orderService.setDao(orderDao);
		uaService.setDao(uaDao);
		ucService.setDao(ucDao);
		
		UserCreds ucToCheck = ucService.getByUserId(5);
		System.out.println(ucToCheck.getLogin());
		
		
		//-----saving user
		UserAddress uaToSave = new UserAddress();
		uaToSave.setCity("Brest");
		Integer uaId = uaService.add(uaToSave);
		uaToSave.setId(uaId);
		
		User userToSave = new User();
		userToSave.setName("Nilolay");
		userToSave.setUserAddress(uaToSave);
		
		
		
		Integer uId = userService.add(userToSave);
		
		UserCreds ucToSave = new UserCreds();
		ucToSave.setUserId(uId);
		ucToSave.setLogin("nikolay");
		
		ucService.add(ucToSave);
		
		
		
		//-----saving user
		Brand b = brandsService.getById(1);
		
		System.out.println(b.getBrandName() + " " + b.getBrandModel());
		
		Brand b2 = new Brand();
		b2.setId(2);
		b2.setBrandName("Vw");
		b2.setBrandModel("Toureg");
		
		Autopart ap = autopartService.getById(1);
		Brand ab = ap.getBrand();
		System.out.println(ap.getName() + " "+ab.getBrandName() +" " + ab.getBrandModel());
		
		
		Autopart ap2 = new Autopart();
		ap2.setName("glass");
		ap2.setBrand(b2);
		//autopartService.add(ap2);
		//brandsService.add(b2);
		
		User user = userService.getById(1);
		System.out.println("Cars amount:" + user.getCars().size());
		Car car = user.getCars().get(0);
		System.out.println(car.getUser().getName());
		System.out.println(car.getUser().getCars().size());
		Brand carBrand = car.getBrand();
		UserAddress ua = user.getUserAddress();
		
		System.out.println(user.getName() + " " + user.getEmail());
		System.out.println(user.getName() + " " + ua.getCity() + " " + ua.getStreet());
		System.out.println(car.getVin() + " " + car.getBodyType());
		System.out.println(carBrand.getBrandName() + " " + carBrand.getBrandModel());
		
		UserSearchParams searchParams = new UserSearchParams();
		searchParams.setEmail("mail");
		searchParams.setCity("gilev");
		List<User> users = userService.search(searchParams);
		
		System.out.println("number of users: " + users.size());
		if (users.size() > 0) {
			System.out.println(users.get(0).getName() + " " + users.get(0).getUserAddress().getStreet());
		}
		
		AutopartSearchParams asp = new AutopartSearchParams();
		asp.setBrandModel("Q3");
		
		List<Autopart> autoparts = autopartService.search(asp);

		System.out.println("number of autoparts from search with SearchParams: " + autoparts.size());
		if (autoparts.size() > 0) {
			System.out.println(autoparts.get(0).getName() + " " + autoparts.get(0).getBrand().getBrandName());
		}
		
		CarSearchParams csp = new CarSearchParams();
		csp.setBrandName("Audi");
		csp.setProductionYear("18");
		
		List<Car> cars = carService.search(csp);
		System.out.println("number of cars: " + cars.size());
		if (cars.size() > 0) {
			System.out.println(cars.get(0).getProductionYear() + " " + cars.get(0).getBrand().getBrandModel());
		}
		
		List<Order> orders = orderService.getOrdersByUserId(1);
		System.out.println("number of orders: " + orders.size());
		
	}

}
