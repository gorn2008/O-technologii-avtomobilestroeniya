package com.senla.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.senla.dao.api.IAutopartDAO;
import com.senla.dao.search.AutopartSearchParams;
import com.senla.model.Autopart;

@Repository
public class AutopartDAO extends BaseDAO<Autopart> implements IAutopartDAO{

	public AutopartDAO() {
		super(Autopart.class);
	}
	
	public List<Autopart> search(Session session, AutopartSearchParams searchParams) {
		Criteria query = session.createCriteria(Autopart.class).createAlias("brand", "brand");
		if (searchParams == null) {
			return query.list();
		}
		if (searchParams.getName() != null && !"".equals(searchParams.getName())) {
			query.add(Restrictions.like("name", searchParams.getName(), MatchMode.ANYWHERE));
		}
		if (searchParams.getBrandName() != null && !"".equals(searchParams.getBrandName())) {
			query.add(Restrictions.like("brand.brandName", searchParams.getBrandName(), MatchMode.ANYWHERE));
		}
		if (searchParams.getBrandModel() != null && !"".equals(searchParams.getBrandModel())) {
			query.add(Restrictions.like("brand.brandModel", searchParams.getBrandModel(), MatchMode.ANYWHERE));
		}
		return query.list();
	}
}