package com.senla.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.senla.dao.api.IBaseDAO;

public class BaseDAO<T> implements IBaseDAO<T> {
	
	protected Class<T> clazz;

	public BaseDAO(Class<T> clazz) {
		this.clazz = clazz;
	}

	public Integer add(Session session, T entity) {
		return (Integer) session.save(entity);		
	}

	public void update(Session session, T entity) {
		session.update(entity);
	}
	
	public T getById(Session session, Integer id) {
		T result = null;
		Criteria query = session.createCriteria(clazz);
		query.add(Restrictions.idEq(id));
		result = (T) query.list().get(0);
		return result;
	}

	public List<T> getAll(Session session) {
		List<T> result = new ArrayList<T>();
		Criteria query = session.createCriteria(clazz);
		result = query.list();
		return result;
	}
	
	public void delete(Session session, T entity) {
		session.delete(entity);
	}
	

}
