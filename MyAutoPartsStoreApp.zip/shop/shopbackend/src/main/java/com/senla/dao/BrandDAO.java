package com.senla.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.senla.dao.api.IBrandDAO;
import com.senla.dao.search.BrandSearchParams;
import com.senla.model.Brand;

@Repository
public class BrandDAO extends BaseDAO<Brand> implements IBrandDAO{

	public BrandDAO() {
		super(Brand.class);
	}

	public List<Brand> search(Session session, BrandSearchParams searchParams) {
		Criteria query = session.createCriteria(Brand.class);
		if (searchParams == null) {
			return query.list();
		}		
		if (searchParams.getBrandName() != null && !"".equals(searchParams.getBrandName())) {
			query.add(Restrictions.like("brandName", searchParams.getBrandName(), MatchMode.ANYWHERE));
		}
		if (searchParams.getBrandModel() != null && !"".equals(searchParams.getBrandModel())) {
			query.add(Restrictions.like("brandModel", searchParams.getBrandModel(), MatchMode.ANYWHERE));
		}		
		return query.list();
	}
	
}
