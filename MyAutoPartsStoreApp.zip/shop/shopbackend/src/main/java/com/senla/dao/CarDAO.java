package com.senla.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.senla.dao.api.ICarDAO;
import com.senla.dao.search.CarSearchParams;
import com.senla.model.Car;

@Repository
public class CarDAO extends BaseDAO<Car> implements ICarDAO{

	public CarDAO() {
		super(Car.class);
	}

	public List<Car> search(Session session, CarSearchParams searchParams) {
		Criteria query = session.createCriteria(Car.class).createAlias("brand", "brand");
		if (searchParams == null) {
			return query.list();
		}
		if (searchParams.getBrandName() != null && !"".equals(searchParams.getBrandName())) {
			query.add(Restrictions.like("brand.brandName", searchParams.getBrandName(), MatchMode.ANYWHERE));
		}
		if (searchParams.getBrandModel() != null && !"".equals(searchParams.getBrandModel())) {
			query.add(Restrictions.like("brand.brandModel", searchParams.getBrandModel(), MatchMode.ANYWHERE));
		}
		if (searchParams.getProductionYear() != null && !"".equals(searchParams.getProductionYear())) {
			query.add(Restrictions.like("productionYear", searchParams.getProductionYear(), MatchMode.ANYWHERE));
		}
		if (searchParams.getFuelType() != null && !"".equals(searchParams.getFuelType())) {
			query.add(Restrictions.like("fuelType", searchParams.getFuelType(), MatchMode.ANYWHERE));
		}
		if (searchParams.getBodyType() != null && !"".equals(searchParams.getBodyType())) {
			query.add(Restrictions.like("bodyType", searchParams.getBodyType(), MatchMode.ANYWHERE));
		}
		return query.list();
	}
}