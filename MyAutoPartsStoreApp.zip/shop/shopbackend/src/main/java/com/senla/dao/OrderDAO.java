package com.senla.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.senla.dao.api.IOrderDAO;
import com.senla.model.Order;

@Repository
public class OrderDAO extends BaseDAO<Order> implements IOrderDAO{

	public OrderDAO() {
		super(Order.class);
	}
	
	public List<Order> getOrdersByUserId(Session session, Integer id) {
		List<Order> result = new ArrayList<Order>();
		Criteria query = session.createCriteria(Order.class).createAlias("client", "client");
		if(id != null) {
			query.add(Restrictions.eq("client.id", id));
			result = query.list();
		}
		return result;
	}

}
