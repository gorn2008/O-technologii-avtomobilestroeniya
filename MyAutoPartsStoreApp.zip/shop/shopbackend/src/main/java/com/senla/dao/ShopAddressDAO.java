package com.senla.dao;

import org.springframework.stereotype.Repository;

import com.senla.dao.api.IShopAddressDAO;
import com.senla.model.ShopAddress;

@Repository
public class ShopAddressDAO extends BaseDAO<ShopAddress> implements IShopAddressDAO{

	public ShopAddressDAO() {
		super(ShopAddress.class);
	}

}