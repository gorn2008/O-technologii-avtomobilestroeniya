package com.senla.dao;

import org.springframework.stereotype.Repository;

import com.senla.dao.api.IShopPhoneDAO;
import com.senla.model.ShopPhone;

@Repository
public class ShopPhoneDAO extends BaseDAO<ShopPhone> implements IShopPhoneDAO{

	public ShopPhoneDAO() {
		super(ShopPhone.class);
	}

}