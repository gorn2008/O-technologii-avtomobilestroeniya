package com.senla.dao;

import org.springframework.stereotype.Repository;

import com.senla.dao.api.IUserAddressDAO;
import com.senla.model.UserAddress;

@Repository
public class UserAddressDAO extends BaseDAO<UserAddress> implements IUserAddressDAO{

	public UserAddressDAO() {
		super(UserAddress.class);
	}

}