package com.senla.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.senla.dao.api.IUserCredsDAO;
import com.senla.model.UserCreds;

@Repository
public class UserCredsDAO extends BaseDAO<UserCreds> implements IUserCredsDAO{

	public UserCredsDAO() {
		super(UserCreds.class);
	}
	
	public UserCreds login(Session session, String login, String password) {
		UserCreds user = null;
		Criteria query = session.createCriteria(UserCreds.class);
		query.add(Restrictions.eq("login", login));
		query.add(Restrictions.eq("password", password));
		user = (UserCreds) query.list().get(0);
		return user;
	}
	
	public UserCreds getByUserId(Session session, Integer id) {
		UserCreds user = null;
		Criteria query = session.createCriteria(UserCreds.class);
		query.add(Restrictions.eq("userId", id));
		user = (UserCreds) query.list().get(0);
		return user;
	}

}