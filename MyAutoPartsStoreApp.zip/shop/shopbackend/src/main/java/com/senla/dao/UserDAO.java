package com.senla.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.senla.dao.api.IUserDAO;
import com.senla.dao.search.UserSearchParams;
import com.senla.model.User;

@Repository
public class UserDAO extends BaseDAO<User> implements IUserDAO {

	public UserDAO() {
		super(User.class);
	}
	
	public List<User> search(Session session, UserSearchParams searchParams) {		
		Criteria query = session.createCriteria(User.class).createAlias("userAddress", "address");
		if (searchParams == null) {
			return query.list();
		}
		if (searchParams.getName() != null && !"".equals(searchParams.getName())) {
			query.add(Restrictions.like("name", searchParams.getName(), MatchMode.ANYWHERE));
		}
		if (searchParams.getLastName() != null && !"".equals(searchParams.getLastName())) {
			query.add(Restrictions.like("lastName", searchParams.getLastName(), MatchMode.ANYWHERE));
		}
		if (searchParams.getEmail() != null && !"".equals(searchParams.getEmail())) {
			query.add(Restrictions.like("email", searchParams.getEmail(), MatchMode.ANYWHERE));
		}
		if (searchParams.getPhone() != null && !"".equals(searchParams.getPhone())) {
			query.add(Restrictions.like("phone", searchParams.getPhone(), MatchMode.ANYWHERE));
		}
		if (searchParams.getCity() != null && !"".equals(searchParams.getCity())) {
			query.add(Restrictions.like("address.city", searchParams.getCity(), MatchMode.ANYWHERE));
		}
		if (searchParams.getStreet() != null && !"".equals(searchParams.getStreet())) {
			query.add(Restrictions.like("address.street", searchParams.getStreet(), MatchMode.ANYWHERE));
		}
		if (searchParams.getHouse() != null && !"".equals(searchParams.getHouse())) {
			query.add(Restrictions.like("address.house", searchParams.getHouse(), MatchMode.ANYWHERE));
		}
		if (searchParams.getFlat() != null && !"".equals(searchParams.getFlat())) {
			query.add(Restrictions.like("address.flat", searchParams.getFlat(), MatchMode.ANYWHERE));
		}
		return query.list();
	}

}
