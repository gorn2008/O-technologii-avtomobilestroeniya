package com.senla.dao.api;

import java.util.List;

import org.hibernate.Session;

import com.senla.dao.search.AutopartSearchParams;
import com.senla.model.Autopart;

public interface IAutopartDAO extends IBaseDAO<Autopart> {
	public List<Autopart> search(Session session, AutopartSearchParams searchParams);
}
