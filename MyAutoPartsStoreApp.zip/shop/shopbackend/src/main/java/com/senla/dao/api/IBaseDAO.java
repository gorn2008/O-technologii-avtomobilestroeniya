package com.senla.dao.api;

import java.util.List;

import org.hibernate.Session;

public interface IBaseDAO<T> {
	public List<T> getAll(Session session);
	
	public T getById(Session session, Integer id);

	public Integer add(Session session, T entity);

	public void update(Session session, T entity);

	public void delete(Session session, T entity);

}
