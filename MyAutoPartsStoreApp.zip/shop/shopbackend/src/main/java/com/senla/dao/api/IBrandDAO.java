package com.senla.dao.api;

import java.util.List;

import org.hibernate.Session;

import com.senla.dao.search.BrandSearchParams;
import com.senla.model.Brand;

public interface IBrandDAO extends IBaseDAO<Brand> {
	
	public List<Brand> search(Session session, BrandSearchParams searchParams);

}
