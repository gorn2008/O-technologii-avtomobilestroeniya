package com.senla.dao.api;

import java.util.List;

import org.hibernate.Session;

import com.senla.dao.search.CarSearchParams;
import com.senla.model.Car;

public interface ICarDAO extends IBaseDAO<Car>{
	public List<Car> search(Session session, CarSearchParams searchParams);
}
