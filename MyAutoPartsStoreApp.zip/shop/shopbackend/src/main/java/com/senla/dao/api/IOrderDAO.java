package com.senla.dao.api;

import java.util.List;

import org.hibernate.Session;

import com.senla.model.Order;


public interface IOrderDAO extends IBaseDAO<Order> {
	
	public List<Order> getOrdersByUserId(Session session, Integer id);

}
