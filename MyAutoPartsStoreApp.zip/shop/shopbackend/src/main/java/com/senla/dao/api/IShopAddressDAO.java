package com.senla.dao.api;

import com.senla.model.ShopAddress;

public interface IShopAddressDAO extends IBaseDAO<ShopAddress>{

}
