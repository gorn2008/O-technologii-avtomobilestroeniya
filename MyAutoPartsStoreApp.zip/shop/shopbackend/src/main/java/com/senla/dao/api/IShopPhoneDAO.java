package com.senla.dao.api;

import com.senla.model.ShopPhone;

public interface IShopPhoneDAO extends IBaseDAO<ShopPhone>{

}
