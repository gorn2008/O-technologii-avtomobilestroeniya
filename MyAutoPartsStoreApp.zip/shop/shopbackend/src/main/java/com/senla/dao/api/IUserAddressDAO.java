package com.senla.dao.api;

import com.senla.model.UserAddress;

public interface IUserAddressDAO extends IBaseDAO<UserAddress> {

}
