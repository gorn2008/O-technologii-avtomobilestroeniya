package com.senla.dao.api;

import org.hibernate.Session;

import com.senla.model.UserCreds;

public interface IUserCredsDAO extends IBaseDAO<UserCreds> {
	
	public UserCreds login(Session session, String login, String password);
	public UserCreds getByUserId(Session session, Integer id);

}
