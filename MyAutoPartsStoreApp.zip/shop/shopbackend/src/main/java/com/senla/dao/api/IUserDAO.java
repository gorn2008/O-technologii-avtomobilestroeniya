package com.senla.dao.api;

import java.util.List;

import org.hibernate.Session;

import com.senla.dao.search.UserSearchParams;
import com.senla.model.User;

public interface IUserDAO extends IBaseDAO<User> {
	public List<User> search(Session session, UserSearchParams searchParams);

}
