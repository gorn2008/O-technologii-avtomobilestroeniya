package com.senla.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IAutopartDAO;
import com.senla.dao.search.AutopartSearchParams;
import com.senla.model.Autopart;
import com.senla.service.api.AbstractService;

@Service
public class AutopartService extends AbstractService {
	
	@Autowired
	private IAutopartDAO dao;
	
	public Autopart getById(Integer id) {
		Autopart result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getById(session, id);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public List<Autopart> search(AutopartSearchParams searchParams) {
		List<Autopart> result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.search(session, searchParams);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public void add(Autopart autopart) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.add(session, autopart);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}
	
	public void update(Autopart autopart) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.update(session, autopart);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}

	public IAutopartDAO getDao() {
		return dao;
	}

	public void setDao(IAutopartDAO dao) {
		this.dao = dao;
	}

}
