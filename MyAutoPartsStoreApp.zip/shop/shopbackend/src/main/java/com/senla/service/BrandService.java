package com.senla.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IBrandDAO;
import com.senla.dao.search.BrandSearchParams;
import com.senla.model.Brand;
import com.senla.service.api.AbstractService;

@Service
public class BrandService extends AbstractService {
	
	@Autowired
	private IBrandDAO dao;
	
	public Brand getById(Integer id) {
		Brand result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getById(session, id);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public List<Brand> search(BrandSearchParams searchParams) {
		List<Brand> result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.search(session, searchParams);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public void add(Brand brand) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.add(session, brand);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}
	
	public void update(Brand brand) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.update(session, brand);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}

	public IBrandDAO getBrandDAO() {
		return dao;
	}

	public void setBrandDAO(IBrandDAO brandDAO) {
		this.dao = brandDAO;
	}	

}
