package com.senla.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.ICarDAO;
import com.senla.dao.search.CarSearchParams;
import com.senla.model.Car;
import com.senla.service.api.AbstractService;

@Service
public class CarService extends AbstractService {
	
	@Autowired
	private ICarDAO dao;
	
	public List<Car> search(CarSearchParams searchParams) {
		List<Car> result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.search(session, searchParams);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public void add(Car car) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.add(session, car);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}

	public ICarDAO getDao() {
		return dao;
	}

	public void setDao(ICarDAO dao) {
		this.dao = dao;
	}
	
}
