package com.senla.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IOrderDAO;
import com.senla.model.Order;
import com.senla.service.api.AbstractService;

@Service
public class OrderService extends AbstractService {

	@Autowired
	private IOrderDAO dao;
	
	public Order getById(Integer id) {
		Order result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getById(session, id);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public void add(Order order) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.add(session, order);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}
	
	public void update(Order order) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.update(session, order);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}
	
	public List<Order> getOrdersByUserId(Integer id) {
		List<Order> result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getOrdersByUserId(session, id);
		} catch (Exception ignore) {
		}		
		return result;
	}

	public IOrderDAO getDao() {
		return dao;
	}

	public void setDao(IOrderDAO dao) {
		this.dao = dao;
	}
}
