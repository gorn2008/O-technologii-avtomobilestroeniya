package com.senla.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IShopAddressDAO;
import com.senla.service.api.AbstractService;

@Service
public class ShopAddressService extends AbstractService {

	@Autowired
	private IShopAddressDAO dao;

	public IShopAddressDAO getDao() {
		return dao;
	}

	public void setDao(IShopAddressDAO dao) {
		this.dao = dao;
	}
	
}
