package com.senla.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IShopPhoneDAO;
import com.senla.service.api.AbstractService;

@Service
public class ShopPhoneService extends AbstractService {
	
	@Autowired
	private IShopPhoneDAO dao;

	public IShopPhoneDAO getDao() {
		return dao;
	}

	public void setDao(IShopPhoneDAO dao) {
		this.dao = dao;
	}

}
