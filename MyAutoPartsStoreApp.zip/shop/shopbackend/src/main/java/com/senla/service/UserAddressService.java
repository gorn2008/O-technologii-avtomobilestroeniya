package com.senla.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IUserAddressDAO;
import com.senla.model.UserAddress;
import com.senla.service.api.AbstractService;

@Service
public class UserAddressService extends AbstractService {
	
	@Autowired
	private IUserAddressDAO dao;
	
	public UserAddress getById(Integer id) {
		UserAddress result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getById(session, id);
		} catch (Exception ignore) {
		}
		return result;
	}
	
	public Integer add(UserAddress ua) {
		Transaction tx = null;
		Integer result = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			result = dao.add(session, ua);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
		return result;
	}
	
	public void update(UserAddress ua) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.update(session, ua);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}

	public IUserAddressDAO getDao() {
		return dao;
	}

	public void setDao(IUserAddressDAO dao) {
		this.dao = dao;
	}

}
