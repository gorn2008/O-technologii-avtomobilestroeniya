package com.senla.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IUserCredsDAO;
import com.senla.model.UserCreds;
import com.senla.service.api.AbstractService;

@Service
public class UserCredsService extends AbstractService {

	@Autowired
	private IUserCredsDAO dao;

	public Integer login(String login, String password) {
		Integer result = null;
		try (Session session = sessionFactory.openSession()) {
			UserCreds uc = dao.login(session, login, password);
			result = uc.getUserId();
		} catch (Exception ignore) {
		}
		return result;
	}

	public UserCreds getById(Integer id) {
		UserCreds result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getById(session, id);
		} catch (Exception ignore) {
		}
		return result;
	}
	
	public UserCreds getByUserId(Integer id) {
		UserCreds result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getByUserId(session, id);
		} catch (Exception ignore) {
		}
		return result;
	}

	public void add(UserCreds uc) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.add(session, uc);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}
	
	public void update(UserCreds uc) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.update(session, uc);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}

	public IUserCredsDAO getDao() {
		return dao;
	}

	public void setDao(IUserCredsDAO dao) {
		this.dao = dao;
	}

}
