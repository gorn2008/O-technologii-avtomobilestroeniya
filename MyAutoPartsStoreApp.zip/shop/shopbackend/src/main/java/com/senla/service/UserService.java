package com.senla.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senla.dao.api.IUserDAO;
import com.senla.dao.search.UserSearchParams;
import com.senla.model.User;
import com.senla.service.api.AbstractService;

@Service
public class UserService extends AbstractService {

	@Autowired
	private IUserDAO dao;
	
	public User getById(Integer id) {
		User result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.getById(session, id);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public List<User> search(UserSearchParams searchParams) {
		List<User> result = null;
		try (Session session = sessionFactory.openSession()) {
			result = dao.search(session, searchParams);
		} catch (Exception ignore) {
		}		
		return result;
	}
	
	public Integer add(User user) {
		Transaction tx = null;
		Integer result = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			result = dao.add(session, user);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
		return result;
	}
	
	public void update(User user) {
		Transaction tx = null;
		try (Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			dao.update(session, user);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
		}
	}

	public IUserDAO getDao() {
		return dao;
	}

	public void setDao(IUserDAO dao) {
		this.dao = dao;
	}
}
