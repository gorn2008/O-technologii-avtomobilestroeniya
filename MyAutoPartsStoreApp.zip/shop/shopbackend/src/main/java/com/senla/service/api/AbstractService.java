package com.senla.service.api;

import org.hibernate.SessionFactory;

import com.senla.util.HibernateUtility;

public class AbstractService {
	protected SessionFactory sessionFactory = HibernateUtility.getInstance().getSessionFactory();

}
