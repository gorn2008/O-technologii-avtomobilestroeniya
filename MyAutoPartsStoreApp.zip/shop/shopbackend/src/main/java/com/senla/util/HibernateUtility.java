package com.senla.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtility {
	private SessionFactory sessionFactory;
	private static HibernateUtility instance;

	private HibernateUtility() {
		buildSessionFactory();
	}

	private void buildSessionFactory() {
		sessionFactory = new Configuration().configure().buildSessionFactory();
	}

	public SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			buildSessionFactory();
		}
		return sessionFactory;
	}

	public static HibernateUtility getInstance() {
		if (instance == null) {
			instance = new HibernateUtility();
		}
		return instance;
	}

	public void closeSessionFactory() {
		if (sessionFactory != null) {
			sessionFactory.close();
		}
	}
}
