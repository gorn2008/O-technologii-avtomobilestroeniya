package com.senla.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.senla.dto.AutopartDto;
import com.senla.model.Autopart;
import com.senla.model.Brand;
import com.senla.service.AutopartService;

@RestController
@RequestMapping("/api/autopart/")
public class AutopartController {
	
	@Autowired
	private AutopartService autopartService;
	
	@RequestMapping(value = "load", method = RequestMethod.GET, produces = "application/json")
	public AutopartDto loadBrand(@RequestParam(value = "id") Integer id) {
		AutopartDto autopartDto = new AutopartDto();
		Autopart autopart = autopartService.getById(id);
		if (autopart == null) {
			return null;
		}			
		autopartDto.setId(autopart.getId());
		autopartDto.setName(autopart.getName());
		Brand brand = autopart.getBrand();
		if (brand == null) {
			return autopartDto;
		}
		autopartDto.setBrandName(brand.getBrandName());
		autopartDto.setBrandModel(brand.getBrandModel());
		return autopartDto;		
	}

}
