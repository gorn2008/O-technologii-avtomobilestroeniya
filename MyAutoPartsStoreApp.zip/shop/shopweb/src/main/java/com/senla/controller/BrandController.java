package com.senla.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.senla.model.Brand;
import com.senla.service.BrandService;

@RestController
@RequestMapping("/api/brand/")
public class BrandController {
	@Autowired
	private BrandService brandService;
	
	@RequestMapping(value = "load", method = RequestMethod.GET, produces = "application/json")
	public Brand loadBrand(@RequestParam(value = "id") Integer id) {
		return brandService.getById(id);		
	}

}
