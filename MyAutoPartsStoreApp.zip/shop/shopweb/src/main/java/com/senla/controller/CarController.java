package com.senla.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.senla.dao.search.CarSearchParams;
import com.senla.dto.CarDto;
import com.senla.model.Car;
import com.senla.service.CarService;

@RestController
@RequestMapping("/api/car/")
public class CarController {
	
	@Autowired
	private CarService carService;
	
	@RequestMapping(value = "search", method = RequestMethod.GET, produces = "application/json")
	public List<CarDto> searchUser(
			@RequestParam(value = "brandName", required = false) String brandName,
			@RequestParam(value = "brandModel", required = false) String brandModel,
			@RequestParam(value = "productionYear", required = false) String productionYear,
			@RequestParam(value = "fuelType", required = false) String fuelType,
			@RequestParam(value = "bodyType", required = false) String bodyType
			) {
		CarSearchParams searchParams = new CarSearchParams();
		
		searchParams.setBrandName(brandName);
		searchParams.setBrandModel(brandModel);
		searchParams.setProductionYear(productionYear);
		searchParams.setFuelType(fuelType);
		searchParams.setBodyType(bodyType);
		
		List<CarDto> result = new ArrayList<CarDto>();
		List<Car> searchResult = carService.search(searchParams);
		if (searchResult == null) {
			return result;
		}
		for (Car car : searchResult) {
			CarDto cDto = new CarDto();
			cDto.setBodyType(car.getBodyType());
			result.add(cDto);
		}
		return result;
	}

}
