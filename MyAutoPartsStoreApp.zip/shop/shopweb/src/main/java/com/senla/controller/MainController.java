package com.senla.controller;

public class MainController {

}
