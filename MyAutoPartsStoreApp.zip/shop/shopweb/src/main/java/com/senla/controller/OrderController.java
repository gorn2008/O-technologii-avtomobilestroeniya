package com.senla.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.senla.dto.OrderDto;
import com.senla.model.Autopart;
import com.senla.model.Order;
import com.senla.model.User;
import com.senla.service.OrderService;

@RestController
@RequestMapping("/api/order/")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@RequestMapping(value = "load", method = RequestMethod.GET, produces = "application/json")
	public OrderDto loadOrder(@RequestParam(value = "id") Integer id) {
		OrderDto orderDto = new OrderDto();
		Order order = orderService.getById(id);
		if(order == null) {
			return null;
		}
		orderDto.setId(order.getId());
		orderDto.setStatus(order.getStatus());
		User user = order.getClient();
		Autopart autopart = order.getAutopart();
		if ((user == null) && (autopart == null)) {
			return orderDto;
		}
		if (user != null) {
			orderDto.setClientId(user.getId());
		}
		if (autopart != null) {
			orderDto.setAutopartId(autopart.getId());
		}		
		return orderDto;
	}

}
