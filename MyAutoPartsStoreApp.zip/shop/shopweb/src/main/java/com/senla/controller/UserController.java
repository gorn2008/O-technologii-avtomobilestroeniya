package com.senla.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.senla.dao.search.UserSearchParams;
import com.senla.dto.UserDto;
import com.senla.model.User;
import com.senla.model.UserAddress;
import com.senla.model.UserCreds;
import com.senla.service.UserAddressService;
import com.senla.service.UserCredsService;
import com.senla.service.UserService;

@RestController
@RequestMapping("/api/user/")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserAddressService userAddressService;
	
	@Autowired
	private UserCredsService userCredsService;
	
	@RequestMapping(value = "load", method = RequestMethod.GET, produces = "application/json")
	public UserDto loadUser(@RequestParam(value = "id") Integer id) {
		User user = userService.getById(id);
		if(user == null) {
			return null;
		}
		UserDto result = new UserDto();
		
		result.setName(user.getName());
		result.setLastName(user.getLastName());
		result.setRole(user.getRole());
		result.setPhone(user.getPhone());
		result.setEmail(user.getEmail());
		UserAddress ua = user.getUserAddress();
		if (ua == null) {
			result.setCity("");
			result.setStreet("");
			result.setHouse("");
			result.setFlat("");
			return result;
		}
		result.setCity(ua.getCity());
		result.setStreet(ua.getStreet());
		result.setHouse(ua.getHouse());
		result.setFlat(ua.getFlat());	
		
		return result;
	}
	
	@RequestMapping(value = "save", method = RequestMethod.POST)
	public void saveUser(@RequestBody UserDto user) {
		if (user == null) {
			return;
		}
		UserAddress ua = new UserAddress();
		ua.setCity(user.getCity());
		ua.setStreet(user.getStreet());
		Integer uaId = userAddressService.add(ua);
		ua.setId(uaId);
		
		User u = new User();
		u.setName(user.getName());
		u.setLastName(user.getLastName());
		u.setEmail(user.getEmail());
		u.setUserAddress(ua);		
		Integer uId = userService.add(u);
		
		UserCreds uc = new UserCreds();
		uc.setLogin(user.getLogin());
		uc.setPassword(user.getPassword());
		uc.setUserId(uId);
		userCredsService.add(uc);
	}
	
	@RequestMapping(value = "update", method = RequestMethod.POST)
	public void updateUser(@RequestBody UserDto user) {
		if (user == null) {
			return;
		}
		if (user.getId() == null) {
			return;
		}
		User u = userService.getById(user.getId());
		if (u == null) {
			return;
		}		
		UserAddress ua = u.getUserAddress();
		if (ua.getId() != null) {
			ua.setCity(user.getCity());
			ua.setStreet(user.getStreet());
			ua.setHouse(user.getHouse());
			ua.setFlat(user.getFlat());
			userAddressService.update(ua);
		}
		u.setUserAddress(ua);
		
		u.setId(user.getId());
		u.setName(user.getName());
		u.setLastName(user.getLastName());
		u.setEmail(user.getEmail());
		u.setPhone(user.getPhone());
		u.setRole(user.getRole());
		userService.update(u);		
		
		UserCreds uc = userCredsService.getByUserId(u.getId());
		if (uc != null) {
			uc.setLogin(user.getLogin());
			uc.setPassword(user.getPassword());
			userCredsService.update(uc);
		}
	}
	
	@RequestMapping(value = "search", method = RequestMethod.GET, produces = "application/json")
	public List<UserDto> searchUser(
			@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "lastName", required = false) String lastName,
			@RequestParam(value = "email", required = false) String email,
			@RequestParam(value = "phone", required = false) String phone,
			@RequestParam(value = "city", required = false) String city,
			@RequestParam(value = "street", required = false) String street,
			@RequestParam(value = "house", required = false) String house,
			@RequestParam(value = "flat", required = false) String flat
			) {
		UserSearchParams searchParams = new UserSearchParams();
		
		searchParams.setName(name);
		searchParams.setLastName(lastName);
		searchParams.setEmail(email);
		searchParams.setPhone(phone);
		searchParams.setCity(city);
		searchParams.setStreet(street);
		searchParams.setHouse(house);
		searchParams.setFlat(flat);
		
		List<UserDto> result = new ArrayList<UserDto>();
		List<User> searchResult = userService.search(searchParams);
		if (searchResult == null) {
			return result;
		}
		for (User user : searchResult) {
			UserDto uDto = new UserDto();
			uDto.setName(user.getName());
			result.add(uDto);
		}
		return result;
	}

}
