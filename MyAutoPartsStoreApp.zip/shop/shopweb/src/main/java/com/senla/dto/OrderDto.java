package com.senla.dto;

public class OrderDto {
	private Integer id;
	private Integer clientId;
	private Integer autopartId;
	private String status;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getClientId() {
		return clientId;
	}
	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	public Integer getAutopartId() {
		return autopartId;
	}
	public void setAutopartId(Integer autopartId) {
		this.autopartId = autopartId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	

}
